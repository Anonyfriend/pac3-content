list.Set( "PlayerOptionsModel", "Simon", "models/h-d/2sg/simonplayer.mdl" )
player_manager.AddValidModel( "Simon", "models/h-d/2sg/simonplayer.mdl" )
player_manager.AddValidHands( "Simon", "models/weapons/c_arms_cstrike.mdl", 0, "00000000" )