local Category = "Vinrax NPCS"
local NPC = {
		 		Name = "SCP 106", 
				Class = "npc_citizen",
				KeyValues = { citizentype = 4 },
				Model = "models/vinrax/player/SCP106_player.mdl",
				Health = "250",
				Category = Category	
		}
list.Set( "NPC", "npc_scp106", NPC )