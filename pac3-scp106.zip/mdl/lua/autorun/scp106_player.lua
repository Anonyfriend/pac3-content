player_manager.AddValidModel( "SCP 106", "models/vinrax/player/SCP106_player.mdl" );
list.Set( "PlayerOptionsModel",  "SCP 106", 					"models/vinrax/player/SCP106_player.mdl" )