player_manager.AddValidModel( "Chibiterasu","models/player_Chibiterasu.mdl" )
player_manager.AddValidHands( "Chibiterasu", "models/amaterasu_arms.mdl", 0, "00000000" )


