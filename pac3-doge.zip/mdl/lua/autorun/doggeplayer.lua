player_manager.AddValidModel( "Doge", "models/doge_player/doge_player.mdl" )
player_manager.AddValidHands( "Doge", "models/doge_player/doge_arms.mdl", 0, "00000000" )
